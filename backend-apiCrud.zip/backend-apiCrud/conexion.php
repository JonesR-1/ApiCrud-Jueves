<?php
// Configuración de la base de datos
$host = 'localhost';
$dbname = 'inventario';
$username = 'root';
$password = '';